#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
#include <thread>

static bool is_correct=false;

void(*func)(const std::vector<char*>&,const std::vector<int>&);

void Find_Someone_Between_30_and_35(const std::vector<char*>& names, const std::vector<int>& ages)
{
    auto the_person_index=
    (std::find_if(ages.begin(),ages.end(),[](int value){return value>=30 && value<=35;}))  - ages.begin();

    (the_person_index<names.size() ? std::cout<<"A person who is between 30 and 35 years old is "<<names[the_person_index]<<"."<<
     std::endl : std::cout<<"There is no person between 30 and 35 years old."<<std::endl);
}

void Find_Someone_Between_25_and_30(const std::vector<char*>& names, const std::vector<int>& ages)
{
    auto the_person_index=(std::find_if(ages.begin(),ages.end(),[](int value)
    {
        return value>=25 && value<=30;
    }))-ages.begin();

    (the_person_index<names.size() ? std::cout<<"A person who is between 25 and 30 years old is "<<names[the_person_index]<<"."<<
     std::endl : std::cout<<"There is no person between 25 and 30 years old."<<std::endl);
}

int main()
{
    std::vector<char*> names= {"Krasi","Meto","Lora","Nina","Stela","Kiko","Martin"};
    std::vector<int>ages= {44,11,22,44,22,52,27};

    int number_of_functions=2;

    void(*func_array[number_of_functions])(const std::vector<char*>&,const std::vector<int>&) =
    {Find_Someone_Between_25_and_30,Find_Someone_Between_30_and_35};

    for(int i =0;i<number_of_functions;++i)
        {
        func=func_array[i];
        func(names,ages);
        }

    std::thread worker([]()
    {
        using namespace std::literals::chrono_literals;

        while(!is_correct)
        {
            std::cout<<"Waiting for your answer..."<<std::endl;
            std::this_thread::sleep_for(5s);
        }
    });

    while(!is_correct)
    {
        std::cout<<"Guess how old exactly is the guy between 25 and 30 ?"<<std::endl;
        int age;
        std::cin>>age;
        if(age==27) {is_correct=true; std::cout<<"You are correct finally!"<<std::endl;}
         else{(std::cout<<std::endl<<"Nope the person is not of that age!"<<std::endl);}
    }

    worker.join();

    std::cout<<"Bye Everybody. Dance now."<<std::endl;
    return 0;
}
